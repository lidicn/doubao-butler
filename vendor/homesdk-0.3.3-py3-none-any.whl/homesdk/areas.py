"""家庭区域：全生态"房间/区域"的唯一机制层入口。

随 homesdk 0.3.3 加入（DCD 2026-11-04 裁定：`20261104-DB-房间定义统一到HA区域三仓契约-裁定.md` T2/T7）。

**为什么需要它**：AF 硬编码 11 个 `AREA_WORDS`（含 HA 没有的 次卧/儿童房/阳台/玄关/餐厅）、
DB `devices.json` 自定 7 个中文房间名（`Kevin房间/Emily房间` 与 HA 的 `房间/卧室` 不一致）、
MA 内部已有 area_id 映射但对外 `room` 走 appearance 中文名——三套口径互不相通。
AF→DB 的 MQTT 发声/问答因房间名对不上会**静默不出声**（台账还记 accepted）。

**口径（裁定：HA `area_id` 为准）**：`area_id` 是 HA 的稳定键（pinyin，如 `shu_fang`），
`area_name` 是显示层（中文，用户可改）。凡跨仓共享的 `room` 字段一律 `area_id`。

**边界**：只管"文本 → area_id 的解析机制"，不管"从哪读 HA"（那是各仓的语义）。
不内置 HA HTTP 调用、不内置 15 个区域的固定表——映射由调用方喂入（各仓从自己的 HA 读）。

**失败**：解析不到 → `None`。★ 契约（裁定 §2.3 硬判据）：`None` ⇒ 调用方**拒绝投递并打日志
`AREA_UNRESOLVED`，⛔ 静默 accepted**。
"""

from __future__ import annotations

from typing import Any, Final

__all__ = [
    "AreaMap",
    "resolve",
    "name",
    "parse",
]

#: area_id → area_name 的映射。由调用方从 HA 读取后喂入（各仓自己的 HA 配置）。
AreaMap = dict[str, str]

#: 别名 → area_id 的过渡映射（仓内旧中文名与 HA 不一致的那类）。
#: 由调用方按仓内历史数据提供；homesdk 不内置任何固定表。
#: 例（DB）：`{"Kevin房间": "fang_jian", "Emily房间": "wo_shi"}`。
DEFAULT_ALIASES: Final[dict[str, str]] = {}


def _normalize(text: Any) -> str:
    """归一化输入：strip 空白，None 转空串。

    ⛔ 不做大小写折叠：area_id 是 pinyin 小写、area_name 是中文，两者都无大小写歧义；
    折叠反而会把"ke_ting"与"KE_TING"混为一谈（HA 的 area_id 恒小写）。
    """
    if text is None:
        return ""
    return str(text).strip()


def parse(raw: Any) -> AreaMap:
    """把 HA 区域映射解析成 `AreaMap`。

    接受两种形状：
    - `dict`：`{"ke_ting": "客厅", ...}`
    - JSON 字符串：`'{"ke_ting": "客厅"}'`

    失败抛 `ValueError`（坏 JSON / 非对象 / 键值非字符串 / 空键空值）——⛔ 静默吞成空表：
    空表会让 `resolve` 对一切输入都返回 None，等于"区域机制整体失效"而不自知。
    """
    if isinstance(raw, dict):
        mapping = raw
    elif isinstance(raw, str):
        import json

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"areas.parse: 坏 JSON（{exc}）") from exc
        mapping = parsed
    else:
        raise ValueError(f"areas.parse: 需要 dict 或 JSON 字符串，收到 {type(raw).__name__}")

    if not isinstance(mapping, dict):
        raise ValueError(f"areas.parse: 需要对象，收到 {type(mapping).__name__}")

    out: AreaMap = {}
    for key, value in mapping.items():
        if not isinstance(key, str) or not isinstance(value, str):
            raise ValueError(
                f"areas.parse: 键值必须都是字符串（收到 {type(key).__name__} → {type(value).__name__}）"
            )
        k = key.strip()
        v = value.strip()
        if not k or not v:
            raise ValueError("areas.parse: 键值不能为空串")
        out[k] = v
    return out


def resolve(
    mapping: AreaMap,
    room_text: Any,
    aliases: dict[str, str] | None = None,
) -> str | None:
    """把任意房间文本解析到 `area_id`。

    匹配顺序（前一个命中即返回）：
    1. 归一化后为空 → `None`
    2. 精确命中 `area_id`（pinyin）
    3. **别名**（仓内旧中文名 → `area_id`；旧名优先，防未来 `area_name` 恰好改名成旧名时误判）
    4. `area_name` 反查（中文名 → `area_id`；同名取首个——HA 的 area_name 在该仓内应唯一）
    5. 都不到 → `None`

    ★ `None` 是契约信号：调用方必须拒绝投递并打日志 `AREA_UNRESOLVED`，⛔ 静默 accepted。
    """
    text = _normalize(room_text)
    if not text:
        return None

    if text in mapping:
        return text

    if aliases:
        aid = aliases.get(text)
        if aid is not None:
            return aid

    for aid, aname in mapping.items():
        if aname == text:
            return aid

    return None


def name(mapping: AreaMap, area_id: Any) -> str | None:
    """`area_id` → 显示层中文名。未知返回 `None`（⛔ 返回输入值：那会把未知 id 当显示名用）。"""
    return mapping.get(_normalize(area_id))
