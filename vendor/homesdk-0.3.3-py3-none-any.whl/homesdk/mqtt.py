"""统一的 MQTT 客户端构造：paho 可选依赖、QoS 默认 1、缺凭据即拒。

本模块**只配置、不连接**：`get_client` 返回一个配好的 Client，
`connect` 由调用方自己发起。这样测试不需要 broker、不需要网络、不需要设备，
而生态里真正需要的东西（paho 版本探测、QoS 一致、凭据策略）也确实在这里收完了。

paho-mqtt 是重依赖，homesdk 不强制安装：

    try: import paho.mqtt.client as mqtt
    except ImportError: mqtt = None

没装时 import 本模块照常成功，调用 `get_client` 才抛 `MqttUnavailable`。

三条策略来自取证现网的真实分裂，不是偏好：

1. **paho API 三形状**。butler `bus/mqtt_client.py:30` 与 DeskPilot
   `mqtt_client.py:138` 用 `Client(callback_api_version=VERSION2, ...)`；
   TVPilot `:2720` 用裸 `Client()`（paho 1.x）；memory-agent `mqtt_bridge.py:71`
   用 `Client(VERSION1, ...)` 并靠 `AttributeError` 回退。不运行时探测就装不上其中一家。
2. **QoS**。butler 全 1、TVPilot 订阅 `face` 用 0、DeskPilot 发布默认 0、
   memory-agent 统一 1 但文档里留着「旧连接残留 qos=0」。默认给 1。
3. **空凭据**。DeskPilot `mqtt_client.py:142`（`if self.username:` 才 `username_pw_set`，
   随后 :151 无条件 `connect`）与 TV `MqttManager.java:143` 都是
   「username 为空就不设置，照样连上」= 匿名接入 broker。一旦拿到这套凭据
   就能发 `butler/trigger/*`、`tv/livingroom/cmd/*`、`deskpilot/cmd/#` 指挥全屋，
   所以这里默认**拒绝**，要匿名连得显式传 `allow_anonymous=True`。

broker 地址同样不内置：`MQTT_HOST` 缺失即抛，与 `homesdk.http` 的「库内零私网地址」同一条规矩。
"""

from __future__ import annotations

import json as _json
import os
from dataclasses import dataclass
from typing import Any, Final

from homesdk.adm.errors import ADM_ERR_BROKER_UNREACHABLE, ADM_ERR_PUBLISH_REFUSED
from homesdk.config import MissingEnv, first_env, get_env_int, require_env
from homesdk.http import peer_name

try:  # 可选依赖：没装 paho 时 homesdk 其余模块必须照常可用
    import paho.mqtt.client as _paho
except ImportError:
    _paho = None

#: 生态统一 QoS。见模块 docstring 第 2 条。
QOS: Final = 1

#: 未显式指定端口时的 broker 端口（协议标准值，不是私网地址）。
DEFAULT_PORT: Final = 1883

#: 自动重连退避区间，交给 paho 自己跑（memory-agent `mqtt_bridge.py:79` 用的就是这对值）。
RECONNECT_MIN: Final = 5
RECONNECT_MAX: Final = 60


class MqttUnavailable(RuntimeError):
    """paho-mqtt 未安装。装它是对**调用方**的要求，不是对 homesdk 的。"""


class MqttCredentialsMissing(MissingEnv):
    """凭据不成套且未显式允许匿名。"""


def paho_available() -> bool:
    """当前环境能否用 `get_client`。"""
    return _paho is not None


def broker_settings() -> tuple[str, int, int]:
    """`(host, port, keepalive)`。host 缺失即抛 `MissingEnv`，**没有内置默认地址**。"""
    host = require_env("MQTT_HOST")
    port = get_env_int("MQTT_PORT", DEFAULT_PORT)
    keepalive = get_env_int("MQTT_KEEPALIVE", 60)
    if port <= 0 or port > 65535:
        raise ValueError(f"MQTT_PORT 越界：{port}")
    return host, port, keepalive


def resolve_credentials(peer: str | None = None, *, allow_anonymous: bool = False) -> tuple[str, str] | None:
    """取 broker 凭据。缺一半视同没有——只带用户名不带口令等于匿名。

    键名收编现网两套：`MQTT_PASSWORD`（butler）与 `MQTT_PASS`（TVPilot / memory-agent）。
    """
    names = () if peer is None else (peer, peer_name(peer))
    users: list[str] = []
    passwords: list[str] = []
    for name in names:
        scoped = peer_name(name)
        users.append(f"MQTT_USER_{scoped}")
        passwords.append(f"MQTT_PASSWORD_{scoped}")
    users += ["MQTT_USER", "MQTT_USERNAME"]
    passwords += ["MQTT_PASSWORD", "MQTT_PASS", "MQTT_PASSWD"]
    user = first_env(tuple(users))
    password = first_env(tuple(passwords))
    if user is None and password is None:
        if allow_anonymous:
            return None
        raise MqttCredentialsMissing(
            "MQTT 凭据未配置：homesdk 不提供默认账密，也不做匿名回退。"
            "确实要匿名连再传 allow_anonymous=True"
        )
    if user is None or password is None:
        raise MqttCredentialsMissing("MQTT 用户名与口令不成套（缺一半视同匿名）")
    return user, password


def default_client_id(peer: str | None = None) -> str:
    """`homesdk-<peer>-<pid>`。

    现网 TVPilot 用裸 `Client()` 让 paho 自动造 id（同一进程重连会撞），
    memory-agent 用 `memory-agent-<epoch>`。显式带 pid 保证同机多实例不互踢。
    """
    suffix = peer_name(peer).lower() if peer else "app"
    return f"homesdk-{suffix}-{os.getpid()}"


def _new_client(client_id: str) -> Any:
    """按 paho 的实际形状构造，从新 API 往下试。

    只捕 `TypeError` / `ValueError`（参数不被接受），不捕 `Exception`：
    构造期真出错要原样冒出来，不能让探测逻辑把它咽成「再试一种写法」。
    """
    version = getattr(_paho, "CallbackAPIVersion", None)
    if version is not None:
        for kwargs in (
            {"callback_api_version": version.VERSION2, "client_id": client_id, "clean_session": False},
            {"callback_api_version": version.VERSION2, "client_id": client_id},
        ):
            try:
                return _paho.Client(**kwargs)
            except (TypeError, ValueError):
                continue
    return _paho.Client(client_id=client_id)


def get_client(
    client_id: str | None = None,
    *,
    peer: str | None = None,
    allow_anonymous: bool = False,
    qos: int = QOS,
) -> Any:
    """返回配好凭据与重连退避的 paho Client，**不连接**。

    用法（连接由调用方发起，`keepalive` 是 `connect` 的参数不是构造参数）：

        client = get_client(peer="butler")
        host, port, keepalive = broker_settings()
        client.connect(host, port, keepalive)
        client.loop_start()

    `qos` 只写进 `client._homesdk_qos` 供 `publish` 取默认值，不改变 paho 行为。
    """
    if _paho is None:
        raise MqttUnavailable("需要 paho-mqtt：pip install paho-mqtt（homesdk 本身不带它）")
    client = _new_client(client_id or default_client_id(peer))
    credentials = resolve_credentials(peer, allow_anonymous=allow_anonymous)
    if credentials is not None:
        client.username_pw_set(credentials[0], credentials[1])
    if hasattr(client, "reconnect_delay_set"):
        client.reconnect_delay_set(RECONNECT_MIN, RECONNECT_MAX)
    if not 0 <= qos <= 2:
        raise ValueError(f"QoS 只能是 0/1/2，收到 {qos}")
    client._homesdk_qos = qos
    return client


#: 「链路是通的、这一条没让发出去」那一族——处置方向是改主题/载荷/队列，不是去修 broker。
#: **一张表两枚投影**：名字面（`.name`，paho 挪数字时判定不跟着漂）与数字面（裸 int 返回值、
#: 以及没装 paho 的那台机器取不到常量时的兜底）必须成对声明，分开写两张表就是自己造第二份真值。
#: 数字按 paho 2.1.0 现读钉住（INVAL=3 / PAYLOAD_SIZE=9 / ACL_DENIED=12 / QUEUE_SIZE=15），
#: 装了 paho 的机器上有一腿拿真常量对撞这几个数。
_PUBLISH_REFUSED_PAIRS: Final[tuple[tuple[str, int], ...]] = (
    ("MQTT_ERR_INVAL", 3),
    ("MQTT_ERR_PAYLOAD_SIZE", 9),
    ("MQTT_ERR_ACL_DENIED", 12),
    ("MQTT_ERR_QUEUE_SIZE", 15),
)
_PUBLISH_REFUSED_NAMES: Final[frozenset[str]] = frozenset(name for name, _ in _PUBLISH_REFUSED_PAIRS)
_PUBLISH_REFUSED_NUMBERS: Final[frozenset[int]] = frozenset(number for _, number in _PUBLISH_REFUSED_PAIRS)


class PublishRefused(RuntimeError):
    """broker/客户端没收这条发布（`publish()` 回了非零 rc）。

    带**码**而不是只带文案：机器要按码分支（契约 §7.2 的纪律是"失败必须带码"），
    人再看 message 里的 rc 原值。`error_code` 由 `classify_publish_rc` 给，
    消费方（AF/MA/DB）一律不许自带第二份 rc→码 映射表（裁定 20261010 §一 Q2 甲）。
    """

    def __init__(self, message: str, *, topic: str, rc: Any, error_code: str) -> None:
        super().__init__(message)
        self.topic = topic
        self.rc = rc
        self.error_code = error_code


def classify_publish_rc(rc: Any) -> str:
    """非零 publish rc → ADM 错误码。生态里这一份是**唯一**真源。

    只分一组方向差（裁定 20261010 §一 Q1 甲）：`ADM_ERR_PUBLISH_REFUSED`（链路在、这条被挡）
    与 `ADM_ERR_BROKER_UNREACHABLE`（链路不在）。认不出的 rc 一律落到后者的保守档——
    把"说不清的失败"指去修 broker 至少不会让人对着一条 ACL 配置空转，而 rc 原值仍在 message 里。
    """
    name = getattr(rc, "name", None)
    if isinstance(name, str) and name:
        return ADM_ERR_PUBLISH_REFUSED if name in _PUBLISH_REFUSED_NAMES else ADM_ERR_BROKER_UNREACHABLE
    try:
        number = int(rc)
    except (TypeError, ValueError):
        return ADM_ERR_BROKER_UNREACHABLE
    return ADM_ERR_PUBLISH_REFUSED if number in _PUBLISH_REFUSED_NUMBERS else ADM_ERR_BROKER_UNREACHABLE


@dataclass(frozen=True)
class PublishResult:
    """一次发布的**读数**：`rc` 原值 + 派生的 `ok` / `error_code`，外加 mid 供排障。

    `rc` 存的是 int（从 paho 的 IntEnum 落下来），这样测试替身与跨版本比较都只有一个口径；
    `mid` 在没装 paho 或替身不给时落 0，不参与判定。
    """

    topic: str
    rc: int
    mid: int = 0

    @property
    def ok(self) -> bool:
        """读不出的 rc 一律算**没成功**（宁可让调用方走失败分支，也不给它一个凭空的绿）。"""
        try:
            return int(self.rc) == 0
        except (TypeError, ValueError):
            return False

    @property
    def error_code(self) -> str | None:
        return None if self.ok else classify_publish_rc(self.rc)

    def raise_if_refused(self) -> "PublishResult":
        """非零 rc 抛具名异常（带码），零 rc 原样返回自己——给"要么静默成功要么当场响"的调用方。"""
        if self.ok:
            return self
        raise PublishRefused(
            f"{self.topic} 未被 broker 接受（publish rc={self.rc!r} → {self.error_code}）",
            topic=self.topic,
            rc=self.rc,
            error_code=self.error_code or ADM_ERR_BROKER_UNREACHABLE,
        )


def publish(client: Any, topic: str, payload: Any = b"", *, qos: int | None = None, retain: bool = False) -> PublishResult:
    """发布，默认 QoS 取 `get_client` 配的那个值（即 1）。

    刻意不做「未连接就自动 connect」：那会把网络调用藏进一个看起来纯本地的函数里，
    也是现网 TVPilot `mqtt_publish_cmds` 每次发自愈重连那条路径的成因。

    **返回 `PublishResult` 而不是 paho 的裸 info**（裁定 20261010 §一 Q2 甲）：paho 常量在这一层，
    rc→语义的翻译就归这一层；调用方各自抄一份 `(rc→码)` 表是第二份真值，且下一家还要再抄一遍。
    不抛异常——`advertise`/`_publish_inbox` 这些站内调用方一直在丢弃返回值，让 `publish()` 开始抛
    等于替 MA/DB 决定它们的错误处理。要"失败即抛"的形状请显式调 `PublishResult.raise_if_refused()`。
    """
    if qos is None:
        qos = getattr(client, "_homesdk_qos", QOS)
    body = payload if isinstance(payload, (bytes, str)) else _json.dumps(payload, ensure_ascii=False)
    info = client.publish(topic, body, qos=qos, retain=retain)
    return PublishResult(topic=topic, rc=getattr(info, "rc", info), mid=getattr(info, "mid", 0))
